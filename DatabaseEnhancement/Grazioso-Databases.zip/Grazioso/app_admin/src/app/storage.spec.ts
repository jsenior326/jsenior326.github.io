import { SESSION_STORAGE } from './storage';

describe('Storage', () => {
  it('should create an instance', () => {
    expect(new Storage()).toBeTruthy();
  });
});

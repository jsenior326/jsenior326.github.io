import { Component } from '@angular/core';

@Component({
  selector: 'app-website-header',
  standalone: true,
  imports: [],
  templateUrl: './website-header.component.html',
  styleUrl: './website-header.component.css'
})
export class WebsiteHeaderComponent {

}
